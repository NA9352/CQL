"""
Behavioral cloning with PyTorch
=========================================
"""
# %%%
# We present here how to perform behavioral cloning on a Minari dataset using `PyTorch <https://pytorch.org/>`_.
# We will start generating the dataset of the expert policy for the `CartPole-v1 <https://gymnasium.farama.org/environments/classic_control/cart_pole/>`_ environment, which is a classic control problem.
# The objective is to balance the pole on the cart, and we receive a reward of +1 for each successful timestep.
import torch.nn as nn
import torch.nn.functional as F
import minari
from torch.utils.data import DataLoader
import gymnasium as gym
from gymnasium import spaces
from agent import CQLSAC
import numpy as np
import torch
from buffer import ReplayBuffer

# %%
# In this scenario, the output dimension will be two, as previously mentioned. As for the input dimension, it will be four, corresponding to the observation space of ``CartPole-v1``.
# Our next step is to load the dataset and set up the training loop. The ``MinariDataset`` is compatible with the PyTorch Dataset API, allowing us to load it directly using `PyTorch DataLoader <https://pytorch.org/docs/stable/data.html>`_.
# However, since each episode can have a varying length, we need to pad them.
# To achieve this, we can utilize the `collate_fn <https://pytorch.org/docs/stable/data.html#working-with-collate-fn>`_ feature of PyTorch DataLoader. Let's create the ``collate_fn`` function:


def collate_fn(batch):
    return {
        "id": torch.Tensor([x.id for x in batch]),
        "seed": torch.Tensor([x.seed for x in batch]),
        "total_timesteps": torch.Tensor([x.total_timesteps for x in batch]),
        "observations": {
            'image': torch.nn.utils.rnn.pad_sequence(
                [torch.as_tensor(x.observations['image']) for x in batch],
                batch_first=True
            ),
            'direction': torch.nn.utils.rnn.pad_sequence(
                [torch.as_tensor(x.observations['direction']) for x in batch],
                batch_first=True
            ),
        },
        "actions": torch.nn.utils.rnn.pad_sequence(
            [torch.as_tensor(x.actions) for x in batch],
            batch_first=True
        ),
        "rewards": torch.nn.utils.rnn.pad_sequence(
            [torch.as_tensor(x.rewards) for x in batch],
            batch_first=True
        ),
        "terminations": torch.nn.utils.rnn.pad_sequence(
            [torch.as_tensor(x.terminations) for x in batch],
            batch_first=True
        ),
        "truncations": torch.nn.utils.rnn.pad_sequence(
            [torch.as_tensor(x.truncations) for x in batch],
            batch_first=True
        )
    }

# %%
# We can now proceed to load the data and create the training loop.
# To begin, let's initialize the DataLoader, neural network, optimizer, and loss.
minari_dataset = minari.load_dataset("minigrid-fourrooms-v0")

dataloader = DataLoader(minari_dataset, batch_size=16, 
                        shuffle=True, collate_fn=collate_fn)


env = minari_dataset.recover_environment()

env.observation_space = spaces.Dict({
            'image': spaces.Box(low=0, high=255, shape=(7, 7, 3), dtype=np.uint8),
            'direction': spaces.Discrete(4), })
observation_space = env.observation_space
action_space = env.action_space

for key, space in observation_space.items():
    assert isinstance(space, (spaces.Box, spaces.Discrete)), f"{key} space is not a Box or Discrete space"
#assert isinstance(observation_space, spaces.Box)
assert isinstance(action_space, spaces.Discrete)
# Calculate the total size of the observation space

obs_space_size = np.prod(observation_space['image'].shape) + 1#observation_space['direction'].n

agent = CQLSAC(obs_space_size, action_space.n,"cpu")
#optimizer = torch.optim.Adam(q_network.parameters())

# %%And now, we can evaluate if the policy learned from the expert!

# %%
buffer_size = 100
batch_size = 64
buffer = ReplayBuffer(buffer_size, batch_size, "cpu")
from random import seed
steps = 100

for i in range(1, steps+1):
    state = env.reset()
    episode_steps = 0
    rewards = 0
    obs, _ = env.reset(seed=seed())
    while True:
        state = np.concatenate((obs['image'].flatten(), np.array([obs['direction']])))   
        action = agent.get_action(state)
        steps += 1
        next_state, reward, done, _, _ = env.step(action)
        next_state = np.concatenate((next_state['image'].flatten(), np.array([next_state['direction']])))
        buffer.add(state, action, reward, next_state, done)
        if len(buffer) >= batch_size:
            policy_loss, alpha_loss, bellmann_error1, bellmann_error2, cql1_loss, cql2_loss, current_alpha, lagrange_alpha_loss, lagrange_alpha = agent.learn(steps, buffer.sample(), gamma=0.99)
        state = next_state
        rewards += reward
        episode_steps += 1
        if done:
            break
# %%
